for (i=0; i<4; i++)
  console.log(`The current value of i is: ${i}.`)